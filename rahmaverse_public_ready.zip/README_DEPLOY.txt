Rahmaverse public deployment package

How to publish:
1. Go to https://app.netlify.com/drop
2. Drag this folder, or drag the ZIP contents after extracting.
3. Netlify will give you a public link.
4. Send that public link to anyone.

Main file: index.html
